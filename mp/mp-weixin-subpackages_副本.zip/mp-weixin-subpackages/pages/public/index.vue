<template>
	<view class="">
		<view class="">
			<text>public</text>
		</view>
		<image src="/pages/public/static/home.png" style="width: 28rpx;height: 28rpx;"></image>
	</view>
	
</template>

<script>
</script>

<style>
</style>