<template>
	<view class="">
		<view class="">
			<text>classify</text>
		</view>
		<image src="/pages/classify/static/home.png" style="width: 28rpx;height: 28rpx;"></image>
	</view>
	
</template>

<script>
</script>

<style>
</style>