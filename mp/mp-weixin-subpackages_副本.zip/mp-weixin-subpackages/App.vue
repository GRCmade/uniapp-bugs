<script setup>
import { onHide, onShow, onLaunch } from '@dcloudio/uni-app';
onLaunch(() => {
});
onShow(() => {});
onHide(() => {});
</script>

<style lang="scss">

</style>
